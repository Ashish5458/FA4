package com.infosys.infymarket.order.dto;




import java.util.Date;

import com.infosys.infymarket.order.entity.Order;

public class OrderDTO {
	
	String orderid;
	String buyerid;
	Double amount;
	Date orderdate;
	String address;
	String status;
	ProductsorderedDTO productsordered;





	public ProductsorderedDTO getProductsordered() {
		return productsordered;
	}





	public void setProductsordered(ProductsorderedDTO productsordered) {
		this.productsordered = productsordered;
	}





	public OrderDTO() {
		super();
	}
	




	public String getOrderid() {
		return orderid;
	}





	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}





	public String getBuyerid() {
		return buyerid;
	}





	public void setBuyerid(String buyerid) {
		this.buyerid = buyerid;
	}





	public Double getAmount() {
		return amount;
	}





	public void setAmount(Double amount) {
		this.amount = amount;
	}





	public Date getOrderdate() {
		return orderdate;
	}





	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}





	public String getAddress() {
		return address;
	}





	public void setAddress(String address) {
		this.address = address;
	}





	public String getStatus() {
		return status;
	}





	public void setStatus(String status) {
		this.status = status;
	}





	// Converts Entity into DTO
	public static OrderDTO valueOf(Order orders) {
		OrderDTO orderDTO = new OrderDTO();
		orderDTO.setOrderid(orders.getOrderid());
		orderDTO.setBuyerid(orders.getBuyerid());
		orderDTO.setAmount(orders.getAmount());
		orderDTO.setOrderdate(orders.getOrderdate());
		orderDTO.setAddress(orders.getAddress());
		orderDTO.setStatus(orders.getStatus());
		ProductsorderedDTO proDTO = new ProductsorderedDTO();
		orderDTO.setProductsordered(proDTO);
		ProductDTO prodDTO = new ProductDTO();
		prodDTO.setPrice(orders.getPrice());
		//orderDTO.setProdid(proDTO);
		return orderDTO;
	}

//	planDTO.setPlanId(cust.getPlanId());
//	custDTO.setCurrentPlan(planDTO);
//	custDTO.setCurrentPlan(planDTO);
//	



//	public static CustomerDTO valueOf(Customer cust) {
//		CustomerDTO custDTO = new CustomerDTO();
//		custDTO.setAge(cust.getAge());
//		custDTO.setGender(cust.getGender());
//		custDTO.setName(cust.getName());
//		custDTO.setPhoneNo(cust.getPhoneNo());
//		custDTO.setAddress(cust.getAddress());
//		PlanDTO planDTO = new PlanDTO();s
//		planDTO.setPlanId(cust.getPlanId());
//		custDTO.setCurrentPlan(planDTO);
//		custDTO.setCurrentPlan(planDTO);
//		
//		
//		
//		return custDTO;




//	public ProductDTO getPrice() {
//		return price;
//	}
//
//
//
//
//
//	public void setPrice(ProductDTO price) {
//		this.price = price;
//	}





	@Override
	public String toString() {
		return "OrderDTO [orderid=" + orderid + ", buyerid=" + buyerid + ", amount=" + amount + ", orderdate="
				+ orderdate + ", address=" + address + ", status=" + status + "]";
	}


	}
