package com.infosys.user.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.infosys.user.dto.BuyerDTO;
import com.infosys.user.dto.CartDTO;
import com.infosys.user.dto.LoginDTO;
import com.infosys.user.dto.SellerDTO;
import com.infosys.user.dto.WishlistDTO;
import com.infosys.user.service.BuyerService;
import com.infosys.user.service.SellerService;

@RestController
public class UserController {

	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
    Environment environment;
    
    @Autowired
    BuyerService buyerService;
    @Autowired
    SellerService sellerService;
    
    //Register-Login-Delete Seller and Buyer Details
    @PostMapping(value = "/api/buyer/register", consumes = MediaType.APPLICATION_JSON_VALUE)
    public void createBuyer(@Valid @RequestBody BuyerDTO buyerDTO) throws Exception{
        logger.info("Creation request for customer {} with data {}", buyerDTO);
        buyerService.saveBuyer(buyerDTO);
    }
    
    
	@GetMapping(value = "/api/buyers", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<BuyerDTO> getAllBuyer() {
		logger.info("Fetching all products");
		return buyerService.getAllBuyer();
	}
	

	@PostMapping(value = "/buyer/login", consumes = MediaType.APPLICATION_JSON_VALUE)
	public boolean login(@RequestBody LoginDTO loginDTO) {
		logger.info("Login request for customer {} with password {}", loginDTO.getEmail(),loginDTO.getPassword());
		return buyerService.login(loginDTO);
	}
	
	
	 @PostMapping(value = "/api/seller/register", consumes = MediaType.APPLICATION_JSON_VALUE)
	    public void createSeller(@Valid @RequestBody SellerDTO sellerDTO) throws Exception{
	        logger.info("Creation request for customer {} with data {}", sellerDTO);
	        sellerService.saveSeller(sellerDTO);
	    }
	 
	
	@GetMapping(value = "/api/sellers", produces = MediaType.APPLICATION_JSON_VALUE)
		public List<SellerDTO> getAllSeller() {
			logger.info("Fetching all products");
			return sellerService.getAllSeller();
		}

	
	@PostMapping(value = "/seller/login", consumes = MediaType.APPLICATION_JSON_VALUE)
		public boolean Login(@RequestBody LoginDTO loginDTO) {
			logger.info("Login request for customer {} with password {}", loginDTO.getEmail(),loginDTO.getPassword());
			return sellerService.login(loginDTO);
		}
		
	
	@DeleteMapping(value = "/buyer/{buyerid}")
		public ResponseEntity<String> deleteBuyer(@PathVariable String buyerid) throws Exception {
			buyerService.deleteBuyer(buyerid);
			String successMessage = environment.getProperty("API.DELETE_SUCCESS");
			return new ResponseEntity<>(successMessage, HttpStatus.OK);
		}
	
		
	@DeleteMapping(value = "/seller/{sellerid}")
		public ResponseEntity<String> deleteSeller(@PathVariable String sellerid) throws Exception {
			sellerService.deleteSeller(sellerid);
			String successMessage = environment.getProperty("API.DELETE_SUCCESS");
			return new ResponseEntity<>(successMessage, HttpStatus.OK);
		}
	
	//Adding and removing products to cart
	@PostMapping(value = "/api/cart/add", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void addCart(@RequestBody CartDTO cartDTO) throws Exception {
		logger.info("Additing to Data {} with data {}", cartDTO);
		buyerService.addToCart(cartDTO);
	}
	
	
	@DeleteMapping(value = "/api/cart/remove", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void RemoveCart(@RequestBody CartDTO cartDTO) throws Exception {
		logger.info("Additing to Data {} with data {}", cartDTO);
		buyerService.removeFromCart(cartDTO);
	}
	
	@PostMapping(value = "/api/wishlist/move", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void moveToCart(@RequestBody WishlistDTO wishDTO, @RequestBody CartDTO cartDTO) throws Exception {
		logger.info("Additing to Data {} with data {}", cartDTO);
		buyerService.addToCart(cartDTO);
	}
	
	//Adding and deleting to wishlist
	@PostMapping(value = "/api/wishlist/add", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void addCart(@RequestBody WishlistDTO wishDTO) throws Exception {
		logger.info("Additing to Data {} with data {}", wishDTO);
		buyerService.addToWishlist(wishDTO);
	}
	
	
	@DeleteMapping(value = "/api/wishlist/remove", consumes = MediaType.APPLICATION_JSON_VALUE)
	public void RemoveCart(@RequestBody WishlistDTO wishDTO) throws Exception {
		logger.info("Additing to Data {} with data {}", wishDTO);
		buyerService.removeFromWishlist(wishDTO);
	}
	
}
