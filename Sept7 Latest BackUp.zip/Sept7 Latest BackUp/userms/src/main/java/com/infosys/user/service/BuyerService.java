package com.infosys.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.user.dto.BuyerDTO;
import com.infosys.user.dto.CartDTO;
import com.infosys.user.dto.LoginDTO;
import com.infosys.user.dto.WishlistDTO;
import com.infosys.user.entity.Buyer;
import com.infosys.user.entity.Cart;
import com.infosys.user.entity.Wishlist;
import com.infosys.user.repository.BuyerRepository;
import com.infosys.user.repository.CartRepository;
import com.infosys.user.repository.WishlistRepository;

@Service
@Transactional
public class BuyerService {
	Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    BuyerRepository buyerRepo;
    
    @Autowired
    CartRepository cartRepo;
    
    @Autowired
    WishlistRepository wishRepo;
    
    
   //Creates new Buyer
    public void saveBuyer(BuyerDTO buyerDTO) throws Exception{
    	Optional<Buyer> optional = buyerRepo.findByphoneno(buyerDTO.getPhoneno());
		if(optional.isPresent()) {
			throw new Exception("Number Already Exist");
		}
        logger.info("Creation request for customer {} with data {}",buyerDTO);
        Buyer buyer = buyerDTO.createBuyer();
        buyerRepo.save(buyer);
    }
    
    //Fetches all buyers details
	public List<BuyerDTO> getAllBuyer() {
		
		List<Buyer> buyers = buyerRepo.findAll();
		List<BuyerDTO> buyerDTOs = new ArrayList<>();

		for (Buyer buyer : buyers) {
			BuyerDTO buyerDTO = BuyerDTO.valueOf(buyer);
			buyerDTOs.add(buyerDTO);
		}

		logger.info("Product Details : {}", buyerDTOs);
		return buyerDTOs;
	}
	
	//Login check
	public boolean login(LoginDTO loginDTO) {
		logger.info("Login request for customer {} with password {}", loginDTO.getEmail(),loginDTO.getPassword());
		Buyer buy = buyerRepo.findByEmail(loginDTO.getEmail());
		if (buy != null && buy.getPassword().equals(loginDTO.getPassword())) {
			return true;
		}
		return false;
	}
	
	//Deletes buyer account
	public void deleteBuyer(String buyerid) throws Exception {
		Optional<Buyer> buyer = buyerRepo.findById(buyerid);
		buyer.orElseThrow(() -> new Exception("Service.Buyer_NOT_FOUND"));
		buyerRepo.deleteById(buyerid);
	}
	
	//Add to cart
	public void addToCart(CartDTO cartDTO)  {
	    Cart cart = cartDTO.createEntity();
		cartRepo.save(cart);
	}
	
	//Remove from cart
	public void removeFromCart(CartDTO cartDTO) throws Exception{
		//Optional<Cart> cart = cartRepo.findByBuyerIdAndProdId(cartDTO.getBuyerid(),cartDTO.getProdid());
		//cart.orElseThrow(() -> new Exception("No data Found with given user data"));
		cartRepo.deleteAll();
	}

	
	public void addToWishlist(WishlistDTO wishDTO)  {
	    Wishlist wish = wishDTO.createEntity();
		wishRepo.save(wish);
	}
	
	public void removeFromWishlist(WishlistDTO wishDTO) throws Exception{
		//Optional<Cart> cart = wishRepo.findByBuyerIdAndProdId(wishDTO.getBuyerid(),wishDTO.getProdid());
		//cart.orElseThrow(() -> new Exception("No data Found with given user data"));
		//wishRepo.deleteByBuyerIdAndProdId(wishDTO.getBuyerid(),wishDTO.getProdid());
	}

}
